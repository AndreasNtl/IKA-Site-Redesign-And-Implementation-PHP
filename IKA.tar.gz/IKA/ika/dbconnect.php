<?php
//connect to mysql database
//$con = mysqli_connect("localhost", "root", "", "ika") or die("Error " . mysqli_error($con));
$con = mysqli_connect("localhost", "dbuser", "1300072_1200212", "sdi1300072") or die("Error " . mysqli_error($con));
?>